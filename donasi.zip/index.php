<?php
include "template/header.php";
include "pages/main.php";
include "template/footer.php";
?>