<?php
include "template/header.php";
include "pages/edit_profile.php";
include "template/footer.php";
?>