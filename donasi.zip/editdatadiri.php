<?php
include "template/header.php";
include "pages/editdatadiri.php";
include "template/footer.php";
?> 
