<?php
include "template/header.php";
include "pages/datadiri.php";
include "template/footer.php";
?> 
