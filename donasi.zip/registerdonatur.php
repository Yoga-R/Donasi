<?php
include "template/header.php";
include "pages/register.php";
include "template/footer.php";
?> 