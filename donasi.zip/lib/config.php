<?php 
$base_url = "http://localhost/donasi/";
$admin_url = "http://localhost/donasi/admin/";
 ?>