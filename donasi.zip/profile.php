<?php
include "template/header.php";
include "pages/profile.php";
include "template/footer.php";
?>